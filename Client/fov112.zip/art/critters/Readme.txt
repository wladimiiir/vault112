
"Khan" critter (nmkhan..)

- All basic animations (A, B, C, R) sets.

- Spear (G), Pistol (H), SMG (I) and Rifle (J) weapon sets.



x'il.